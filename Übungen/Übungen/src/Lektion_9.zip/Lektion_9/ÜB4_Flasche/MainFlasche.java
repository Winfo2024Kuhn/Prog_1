package Lektion_9.ÜB4_Flasche;

public class MainFlasche {
    // Main-Methode
    public static void main(String[] args) {
        // Flasche mit gültigen Werten erstellen
        Flasche flasche1 = new Flasche("Sprudelwasser", "Frisches Quellwasser", 750);

        // Flasche mit ungültiger Kapazität erstellen
        Flasche flasche2 = new Flasche("Cola", "Erfrischungsgetränk", -500);
        flasche2.setFüllstand(500);

        // Beide Flaschen ausgeben
        System.out.println("Flasche 1:");
        Flasche.print(flasche1);

        System.out.println("\nFlasche 2:");
        Flasche.print(flasche2);
    }
}
