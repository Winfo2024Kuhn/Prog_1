package Lektion_9.ÜB4_Flasche;

public class Flasche {
    // Attribute der Klasse (privat für Information Hiding)
    private String name; // Name der Flasche
    private String text; // Text auf der Flasche (Etikett)
    private int kapazität; // Kapazität in ml
    private int füllstand; // Aktueller Füllstand in ml

    // Konstruktor mit Überprüfung der Kapazität
    public Flasche(String name, String text, int kapazität) {
        this.name = name;
        this.text = text;

        // Kapazität prüfen (muss > 0 sein)
        if (kapazität > 0) {
            this.kapazität = kapazität;
        } else {
            this.kapazität = 1000; // Standardwert: 1 Liter
        }

        this.füllstand = this.kapazität; // Flaschen sind standardmäßig voll
    }

    // Getter-Methoden für die Attribute (falls benötigt)
    public String getName() {
        return name;
    }

    public String getText() {
        return text;
    }

    public int getKapazität() {
        return kapazität;
    }

    public int getFüllstand() {
        return füllstand;
    }

    //Setter-Methoden für die Attribute
    public void setFüllstand(int x) {
        if (x < 0) { // Füllstand darf nicht negativ sein
            System.out.println("Der Füllstand kann nicht negativ sein. Der Wert bleibt unverändert.");
        } else if (x > kapazität) { // Füllstand darf Kapazität nicht überschreiten
            System.out.println("Der Füllstand kann die Kapazität der Flasche nicht überschreiten. Setze auf maximale Kapazität.");
            this.füllstand = kapazität; // Setze auf maximale Kapazität
        } else {
            this.füllstand = x; // Setze auf den übergebenen Wert
        }
    }

    // Methode, um die Flasche zu leeren (optional)
    public void entleeren() {
        this.füllstand = 0; // Füllstand auf 0 setzen
    }

    // Methode, um die Flasche zu füllen (optional)
    public void füllen() {
        this.füllstand = this.kapazität; // Füllstand auf maximale Kapazität setzen
    }

    // Methode, um alle Attribute der Flasche auszugeben
    public static void print(Flasche flasche) {
        System.out.println("Name: " + flasche.getName());
        System.out.println("Text: " + flasche.getText());
        System.out.println("Kapazität: " + flasche.getKapazität() + " ml");
        System.out.println("Füllstand: " + flasche.getFüllstand() + " ml");
    }
}


